# NodeSpark Blockchain

NodeSpark es una blockchain con nodos, minería PoW, wallet, explorador y Web3 RPC.
- Moneda: NodeSpark (NSP)
- Supply: 1,000,000,000 NSP
