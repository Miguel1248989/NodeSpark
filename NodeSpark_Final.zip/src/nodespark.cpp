
// nodespark.cpp - Configuración inicial de la blockchain NodeSpark
// Proyecto basado en Bitcoin Core

#include <iostream>
using namespace std;

int main() {
    string blockchain_name = "NodeSpark";
    string coin_symbol = "NSP";
    unsigned long long max_supply = 1000000000;

    cout << "🚀 Bienvenido a " << blockchain_name << " Blockchain!" << endl;
    cout << "Moneda: " << coin_symbol << endl;
    cout << "Supply Máximo: " << max_supply << " " << coin_symbol << endl;
    cout << "Minado activo usando Proof of Work (SHA-256)..." << endl;
    cout << "Inicializando nodo principal..." << endl;

    // Aquí irían más configuraciones del genesis block, red, puertos RPC, etc.

    return 0;
}
